const { Pool } = require('pg');


const pool = new Pool ({
    host: 'localhost',
    port: 5432,
    user:'postgres',
    password: '6651',
    database:'bancosolar'
});

const nuevoUsuario = async(datos) => {
    const consulta = {
        text: 'INSERT INTO usuarios(nombre, balance) VALUES ($1, $2)  RETURNING *;',
        values: datos 
    }

    try {
        const resultado = await pool.query(consulta);
        return resultado.rows[0]
    } catch (e) {
        console.log(e.code);
        return e;
    }
}

const allusers = async() => {
    try {
        const resultado = await pool.query('SELECT * FROM usuarios');
        return resultado.rows;
    } catch (error) {
        console.log(error.code);
        return error;
    }
}

const updateuser = async(datos) =>{
    const consulta = {
        text: `UPDATE usuarios SET nombre = $2,balance = $3 WHERE id = $1 RETURNING *;`,
        values: datos
    }
    try {
        const resultado = await pool.query(consulta);
        return resultado.rows;
    } catch (error) {
        console.log(error.code);
        return error;
    }
}

const deleteuser = async(id) => {
    const consulta = {
        text: `DELETE FROM usuarios WHERE id=${id}`,
    }
    try {
        const resultado = await pool.query(consulta);
        return resultado.rows[0];
    } catch (error) {
        console.error(error);
        return error;
    }
}


const transferIn = async(emisor_, receptor_, monto_, fecha_) => {
    try {
        await pool.query('BEGIN');
        await pool.query(`INSERT INTO transferencias (emisor, receptor, monto, fecha) VALUES (${emisor_}, ${receptor_},${monto_},${fecha_}) RETURNING *;`);
        await pool.query(`UPDATE usuarios SET balance = balance - ${monto_} WHERE emisor = ${emisor_} RETURNING *;`);
        await pool.query(`UPDATE usuarios SET balance = balance + ${monto_} WHERE receptor = ${receptor_} RETURNING *;`);
        await pool.query('COMMIT');
    } catch (error) {
        await pool.query('ROLLBACK');
        return error.code;
    }
}

const transferOut = async() => {
    try {
        const consulta = {
            text: 'SELECT * FROM transferencias',
            rowMode: 'array'
        }
        const resultado = await pool.query(consulta);
        return resultado.rows;   
    } catch (error) {
        console.log(error.code);
        return error;
    }    
}

module.exports = {
    nuevoUsuario,
    allusers,
    updateuser,
    deleteuser,
    transferIn,
    transferOut
}