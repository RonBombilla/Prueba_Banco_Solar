const http = require('http');
const fs = require('fs');
const url = require('url');
const {nuevoUsuario,allusers,updateuser,deleteuser,transferIn, transferOut} = require("./conexion");

http.createServer(async(req, res) => {
    if(req.url == "/" && req.method == 'GET'){
        res.setHeader('content-type','text/html');
        const html = fs.readFileSync('index.html', 'utf8');
        res.end(html);
    }
    
    if(req.url == "/usuario" && req.method == "POST"){
        let body = "";
        req.on('data', (chunk) => {
            body += chunk;
        }).on('end', async() => {
            const datos = Object.values(JSON.parse(body));
            const resultado = await nuevoUsuario(datos);
            res.end(JSON.stringify(resultado));
        });
    }

    if (req.url == "/usuarios" && req.method == "GET") {
        const resultado = await allusers();
        res.end(JSON.stringify(resultado));
    }

    if(req.url.startsWith("/usuario") && req.method == "PUT"){
        let body = "";
        req.on('data',(chunk)=>{
            body += chunk;
        }).on('end', async() => {
            const datos = Object.values(JSON.parse(body));
            const resultado = await updateuser(datos);
            res.end(JSON.stringify(resultado));
        });
    }

    if(req.url.startsWith("/usuario") && req.method == "DELETE"){
        const { id } = url.parse(req.url, true).query;
        const resultado = await deleteuser(datos);
        res.end(JSON.stringify(resultado));
    }

    if(req.url.startsWith('/transferencia') && req.method == 'POST'){
        const {emi, rec, mon, fec} = url.parse(req.url, true).query;
        const resultado = await transferIn(emi, rec, mon, fec);
        res.end(JSON.stringify(resultado));
    }

    if(req.url == '/transferencias' && req.method == 'GET'){
        const resultado = await transferOut();
        res.end(JSON.stringify(resultado));
    }
}).listen(3000, console.log('Server on running port 3000.... '+ process.pid));